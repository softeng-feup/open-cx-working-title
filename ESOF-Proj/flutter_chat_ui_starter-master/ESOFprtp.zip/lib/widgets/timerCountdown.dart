import 'package:flutter/material.dart';

class CategorySelector extends StatefulWidget {
  @override
  _CategorySelectorState createState() => _CategorySelectorState();
}

class _CategorySelectorState extends State<CategorySelector> {
  
  
  @override
  Widget build(BuildContext context) {
    return Container(
      RaisedButton(onPressed: () {
            startTimer();
          },
          child: Text("start"),
          ),
      height: 90.0,
      color: Theme.of(context).primaryColor,
      
    );
  }
}